<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Exclude sticky posts in Elementor Posts widget
add_action( 'elementor/query/exclude_sticky', function( $query ) {
    $query->set( 'post__not_in', get_option( 'sticky_posts' ) );
});
